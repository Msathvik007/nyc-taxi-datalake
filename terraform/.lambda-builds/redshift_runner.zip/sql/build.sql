-- Core schemas for the project
create schema if not exists stg;
create schema if not exists dw;
create schema if not exists analytics;

-- External schema for curated data (Glue DB: db_curated)
create external schema if not exists ext_curated
from data catalog
database 'db_curated'
iam_role '${REDSHIFT_IAM_ROLE_ARN}';

-- External schema for master data (Glue DB: db_master_stepfunction)
create external schema if not exists ext_master
from data catalog
database 'db_master_stepfunction'
iam_role '${REDSHIFT_IAM_ROLE_ARN}';

drop table if exists stg.trips_curated CASCADE;

create table stg.trips_curated as
select *
from ext_curated.yellow_trips_enriched;

drop table if exists stg.vendor_master CASCADE;

create table stg.vendor_master as
select *
from ext_master.vendor_master;

drop table if exists stg.zone_golden CASCADE;

create table stg.zone_golden as
select *
from ext_master.taxi_zone_master;

drop table if exists stg.ratecode CASCADE;

create table stg.ratecode as
select *
from ext_master.ratecode_master;

drop table if exists dw.zone_dim CASCADE;

create table dw.zone_dim (
  zone_sk      bigint identity(1,1) primary key,
  location_id  integer not null,
  borough      varchar(64),
  zone         varchar(128),
  service_zone varchar(64)
)
diststyle all;

insert into dw.zone_dim (location_id, borough, zone, service_zone)
select distinct
  survivor_location_id,
  borough,
  zone_name,
  service_zone
from stg.zone_golden;

drop table if exists dw.vendor_dim CASCADE;

create table dw.vendor_dim (
  vendor_sk   bigint identity(1,1) primary key,
  vendor_id   integer not null,
  vendor_name varchar(128)
)
diststyle all;

insert into dw.vendor_dim (vendor_id, vendor_name)
select distinct
  vendor_id,
  vendor_name
from stg.vendor_master;

drop table if exists dw.ratecode_dim CASCADE;

create table dw.ratecode_dim (
  ratecode_sk   bigint identity(1,1) primary key,
  ratecode_id   integer not null,
  ratecode_desc varchar(128)
)
diststyle all;

insert into dw.ratecode_dim (ratecode_id, ratecode_desc)
select distinct
  ratecode_id,
  ratecode_desc
from stg.ratecode;

drop table if exists dw.fact_trips CASCADE;

create table dw.fact_trips (
  fact_trip_sk          bigint identity(1,1),
  pickup_ts             timestamp,
  dropoff_ts            timestamp,
  pickup_zone_sk        bigint,
  dropoff_zone_sk       bigint,
  vendor_sk             bigint,
  ratecode_sk           bigint,
  passenger_count       integer,
  trip_distance         double precision,
  trip_duration_minutes double precision,
  fare_amount           double precision,
  tip_amount            double precision,
  total_amount          double precision
)
distkey(pickup_zone_sk)
sortkey(pickup_ts);

insert into dw.fact_trips (
  pickup_ts, dropoff_ts,
  pickup_zone_sk, dropoff_zone_sk,
  vendor_sk, ratecode_sk,
  passenger_count, trip_distance, trip_duration_minutes,
  fare_amount, tip_amount, total_amount
)
select
  t.tpep_pickup_datetime as pickup_ts,
  t.tpep_dropoff_datetime as dropoff_ts,
  pz.zone_sk as pickup_zone_sk,
  dz.zone_sk as dropoff_zone_sk,
  v.vendor_sk as vendor_sk,
  r.ratecode_sk as ratecode_sk,
  t.passenger_count,
  t.trip_distance,
  case
    when t.tpep_pickup_datetime is not null
     and t.tpep_dropoff_datetime is not null
     and t.tpep_dropoff_datetime >= t.tpep_pickup_datetime
    then datediff(second, t.tpep_pickup_datetime, t.tpep_dropoff_datetime) / 60.0
    else null
  end as trip_duration_minutes,
  t.fare_amount,
  t.tip_amount,
  t.total_amount
from stg.trips_curated t
left join dw.zone_dim pz on pz.location_id = t.pulocationid
left join dw.zone_dim dz on dz.location_id = t.dolocationid
left join dw.vendor_dim v on v.vendor_id = t.vendorid
left join dw.ratecode_dim r on r.ratecode_id = t.ratecodeid;

create or replace view analytics.v_zone_demand_revenue as
select
  date_trunc('day', f.pickup_ts) as day,
  z.borough,
  z.zone,
  count(*) as trip_count,
  sum(f.total_amount) as total_revenue,
  avg(f.fare_amount) as avg_fare,
  avg(f.tip_amount) as avg_tip
from dw.fact_trips f
join dw.zone_dim z
  on f.pickup_zone_sk = z.zone_sk
group by 1,2,3;

create or replace view analytics.v_vendor_performance as
select
  v.vendor_name,
  count(*) as trip_count,
  sum(f.total_amount) as total_revenue,
  avg(f.trip_distance) as avg_trip_distance,
  avg(f.trip_duration_minutes) as avg_duration_minutes,
  case when sum(f.fare_amount) = 0 then null
       else sum(f.tip_amount) / sum(f.fare_amount)
  end as tip_rate
from dw.fact_trips f
join dw.vendor_dim v
  on f.vendor_sk = v.vendor_sk
group by 1;
