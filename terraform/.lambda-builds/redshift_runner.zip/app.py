import os
import time
import json
import boto3


def _load_dotenv(dotenv_path: str = ".env", override: bool = False) -> None:
    """
    Minimal .env loader (no external dependency).
    Loads KEY=VALUE pairs into os.environ if the file exists.

    Notes:
    - Lines starting with '#' are ignored
    - Blank lines are ignored
    - Surrounding quotes in values are stripped
    """
    try:
        if not os.path.exists(dotenv_path):
            return

        with open(dotenv_path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip("'").strip('"')
                if not key:
                    continue
                if not override and key in os.environ:
                    continue
                os.environ[key] = value
        print(f"Loaded env from {dotenv_path}")
    except Exception as e:
        # Don't fail Lambda because of .env parsing; just log.
        print(f"Failed to load {dotenv_path}: {e}")


# Load packaged .env (if present) BEFORE reading os.getenv(...) below.
_load_dotenv(os.getenv("DOTENV_PATH", ".env"))

# -----------------------------
# CONFIG (prefer env vars in Lambda)
# -----------------------------
AWS_REGION = os.getenv("AWS_REGION", "us-east-2")

NAMESPACE_NAME = os.getenv("NAMESPACE_NAME", "nyc-taxi-namespace")
WORKGROUP_NAME = os.getenv("WORKGROUP_NAME", "nyc-taxi-workgroup")
DATABASE_NAME = os.getenv("DATABASE_NAME", "dev")
SECRET_ARN = os.getenv("SECRET_ARN", "")

# IAM Role that Redshift Serverless will assume to read Glue/S3 (Spectrum/CTAS)
REDSHIFT_IAM_ROLE_ARN = os.getenv(
    "REDSHIFT_IAM_ROLE_ARN",
    "arn:aws:iam::887549718907:role/service-role/AmazonRedshift-CommandsAccessRole-20260118T201053",
)

# Glue catalog DB + tables
GLUE_DB_CURATED = os.getenv("GLUE_DB_CURATED", "db_curated")
GLUE_DB_MASTER = os.getenv("GLUE_DB_MASTER", "db_master")

GLUE_TABLE_TRIPS = os.getenv("GLUE_TABLE_TRIPS", "yellow_trips_enriched")
GLUE_TABLE_ZONES = os.getenv("GLUE_TABLE_ZONES", "taxi_zone_master")
GLUE_TABLE_VENDORS = os.getenv("GLUE_TABLE_VENDORS", "vendor_master")
GLUE_TABLE_RATECODE = os.getenv("GLUE_TABLE_RATECODE", "ratecode_master")
SQL_FILE_PATH = os.getenv("SQL_FILE_PATH", "sql/build.sql")

# Polling
SQL_POLL_SECONDS = float(os.getenv("SQL_POLL_SECONDS", "1.5"))


# -----------------------------
# boto3 clients
# -----------------------------
rsdata = boto3.client("redshift-data", region_name=AWS_REGION)


# -----------------------------
# Helpers: Data API execution
# -----------------------------
def exec_sql(sql: str, database: str = DATABASE_NAME, workgroup: str = WORKGROUP_NAME):
    """Execute SQL via Redshift Data API and wait for completion."""
    resp = rsdata.execute_statement(
        WorkgroupName=workgroup,
        Database=database,
        SecretArn=SECRET_ARN,
        Sql=sql,
    )
    statement_id = resp["Id"]

    while True:
        d = rsdata.describe_statement(Id=statement_id)
        status = d["Status"]
        if status in ("FINISHED", "FAILED", "ABORTED"):
            if status != "FINISHED":
                raise RuntimeError(
                    f"SQL failed ({status}).\n"
                    f"Error: {d.get('Error', 'unknown')}\n"
                    f"Query: {sql}"
                )
            return d
        time.sleep(SQL_POLL_SECONDS)


def exec_sql_many(statements):
    """Execute multiple SQL statements sequentially."""
    executed_count = 0
    last_statement = None

    for s in statements:
        if s and str(s).strip():
            desc = exec_sql(s)
            executed_count += 1
            last_statement = {
                "statement_id": desc.get("Id"),
                "status": desc.get("Status"),
            }

    return {
        "executed_count": executed_count,
        "last_statement": last_statement,
    }


# -----------------------------
# SQL file loading
# -----------------------------
def _resolve_sql_file_path() -> str:
    if os.path.isabs(SQL_FILE_PATH):
        return SQL_FILE_PATH
    return os.path.join(os.path.dirname(__file__), SQL_FILE_PATH)


def _apply_sql_template_vars(sql_text: str) -> str:
    """Replace ${VAR} placeholders in SQL file with env-configured values."""
    replacements = {
        "${REDSHIFT_IAM_ROLE_ARN}": REDSHIFT_IAM_ROLE_ARN,
        "${GLUE_DB_CURATED}": GLUE_DB_CURATED,
        "${GLUE_DB_MASTER}": GLUE_DB_MASTER,
        "${GLUE_TABLE_TRIPS}": GLUE_TABLE_TRIPS,
        "${GLUE_TABLE_ZONES}": GLUE_TABLE_ZONES,
        "${GLUE_TABLE_VENDORS}": GLUE_TABLE_VENDORS,
        "${GLUE_TABLE_RATECODE}": GLUE_TABLE_RATECODE,
    }
    out = sql_text
    for token, value in replacements.items():
        out = out.replace(token, value)
    return out


def _split_sql_statements(sql_text: str):
    """
    Split simple semicolon-delimited SQL into statements.
    Assumes no stored procedures / $$ blocks.
    """
    cleaned_lines = []
    for line in sql_text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("--"):
            continue
        cleaned_lines.append(line)

    normalized = "\n".join(cleaned_lines)
    chunks = [c.strip() for c in normalized.split(";")]
    return [f"{c};" for c in chunks if c]


def load_sql_statements():
    sql_path = _resolve_sql_file_path()
    if not os.path.exists(sql_path):
        raise FileNotFoundError(f"SQL file not found: {sql_path}")

    with open(sql_path, "r", encoding="utf-8") as f:
        raw_sql = f.read()

    rendered_sql = _apply_sql_template_vars(raw_sql)
    statements = _split_sql_statements(rendered_sql)
    if not statements:
        raise ValueError(f"No executable SQL statements found in {sql_path}")
    return sql_path, statements


def run_build():
    print(f"Region: {AWS_REGION}")
    if not WORKGROUP_NAME or not DATABASE_NAME or not SECRET_ARN:
        raise ValueError("Missing required config: WORKGROUP_NAME, DATABASE_NAME, SECRET_ARN")
    print("Running SQL build against existing Redshift workgroup...")

    sql_path, sql_statements = load_sql_statements()
    exec_summary = exec_sql_many(sql_statements)

    print("DONE")
    return {
        "ok": True,
        "namespace": NAMESPACE_NAME,
        "workgroup": WORKGROUP_NAME,
        "database": DATABASE_NAME,
        "sql_file": sql_path,
        "statements_count": len(sql_statements),
        "executed_count": exec_summary["executed_count"],
        "last_statement": exec_summary["last_statement"],
    }


def lambda_handler(event, context):
    """
    Lambda entrypoint.
    """
    return run_build()


def main():
    out = run_build()
    print(json.dumps(out, indent=2))
    print("\nTry:")
    print("  select * from analytics.v_zone_demand_revenue limit 10;")
    print("  select * from analytics.v_vendor_performance limit 10;")


if __name__ == "__main__":
    main()
