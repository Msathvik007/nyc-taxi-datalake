# redshift-runner packaging notes

This Lambda expects the SQL file to exist at runtime:

- `/var/task/sql/build.sql`

By default, `app.py` reads `SQL_FILE_PATH=sql/build.sql` relative to the Lambda code root.

## If deploying manually as zip

From `lambdas/redshift-runner`:

```bash
zip -r redshift-runner.zip app.py sql/
```

Then upload `redshift-runner.zip` to Lambda.

## Required Lambda environment variables

- `AWS_REGION`
- `WORKGROUP_NAME`
- `DATABASE_NAME`
- `SECRET_ARN`
- `REDSHIFT_IAM_ROLE_ARN`

Optional:

- `SQL_FILE_PATH` (defaults to `sql/build.sql`)
- `DOTENV_PATH` (defaults to `.env`, only if packaged and used)

## Verify views after run

In Redshift Query Editor v2:

```sql
select * from analytics.v_zone_demand_revenue limit 10;
select * from analytics.v_vendor_performance limit 10;
```

These views are intended as QuickSight dataset sources.
